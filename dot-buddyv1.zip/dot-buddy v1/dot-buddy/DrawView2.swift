//
//  DrawView2.swift
//  DotBuddy v3
//
//  Created by Julian Quevedo on 3/13/19.
//  Copyright © 2019 Julian Quevedo. All rights reserved.
//

import UIKit

enum Shape2 {
    case circle
}

class DrawView2: UIView {
    
    var currentShape: Shape2?
    
    
    // Only override draw() if you perform custom drawing.
    // An empty implementation adversely affects performance during animation.
    override func draw(_ rect: CGRect) {
        // Drawing code
        
        
        
        guard let currentContext = UIGraphicsGetCurrentContext() else {
            print("Could not get the context")
            return
        }
        
        drawCircle(using: currentContext)
    }
    
    private func drawCircle(using context: CGContext) {
        let centerPoint = CGPoint(x: 25, y: 25)
        
        context.addArc(center: centerPoint, radius: 22, startAngle: CGFloat(0), endAngle: CGFloat(6.3), clockwise: true)
        
        context.setLineWidth(3)
        
        context.setStrokeColor(#colorLiteral(red: 0.3540963111, green: 0.2453525429, blue: 0.7051287241, alpha: 1))
        context.strokePath()
    }
    
    func drawShape(selectedShape: Shape2) {
        currentShape = selectedShape
        setNeedsDisplay()
    }
    
    
}
