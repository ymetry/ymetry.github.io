//
//  DrawView3.swift
//  DotBuddy v3
//
//  Created by Julian Quevedo on 3/13/19.
//  Copyright © 2019 Julian Quevedo. All rights reserved.
//

import UIKit

enum Shape3 {
    case rectangle
}
class DrawView3: UIView {
    
    var currentShape: Shape3?
    
    // Only override draw() if you perform custom drawing.
    // An empty implementation adversely affects performance during animation.
    override func draw(_ rect: CGRect) {
        // Drawing code
        
        guard let currentContext = UIGraphicsGetCurrentContext() else {
            print("Could not get the context")
            return
        }
        
        drawRectangle(using: currentContext)
    }
    
    
    private func drawRectangle(using context: CGContext) {
        
        let xDistance: CGFloat = bounds.size.width/2 - 2
        let yDistance: CGFloat = bounds.size.height/2 - 2
        
        let centerPoint = CGPoint(x: bounds.size.width/2, y: bounds.size.height/2)
        let lowerLeftCorner = CGPoint(x: centerPoint.x - xDistance, y: centerPoint.y + yDistance)
        let lowerRightCorner = CGPoint(x: centerPoint.x + xDistance, y: centerPoint.y + yDistance)
        let upperRightCorner = CGPoint(x: centerPoint.x + xDistance, y: centerPoint.y - yDistance)
        let upperLeftCorner = CGPoint(x: centerPoint.x - xDistance, y: centerPoint.y - yDistance)
        
        context.move(to: lowerLeftCorner)
        context.addLine(to: lowerLeftCorner)
        context.addLine(to: lowerRightCorner)
        context.addLine(to: upperRightCorner)
        context.addLine(to: upperLeftCorner)
        context.addLine(to: lowerLeftCorner)
        
        context.setLineCap(.round)
        context.setLineWidth(2)
        
        context.setStrokeColor(#colorLiteral(red: 0.3540963111, green: 0.2453525429, blue: 0.7051287241, alpha: 1))
        context.strokePath()
    }
    
    func drawShape(selectedShape: Shape3) {
        currentShape = selectedShape
        setNeedsDisplay()
    }
    
    
    
}
