//
//  EntriesController.swift
//  DotBuddy v3
//
//  Created by Julian Quevedo on 3/13/19.
//  Copyright © 2019 Julian Quevedo. All rights reserved.
//

import UIKit

var sheets: [DotSheet] = []

var myIndex = 0

var editingCoords: Bool = false
var tempSheet: DotSheet = DotSheet()

var justLaunched = true

class EntriesController: UIViewController {
    
    @IBOutlet weak var SheetTableView: UITableView!
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        SheetTableView.delegate = self
        SheetTableView.dataSource = self
        
        
        if (justLaunched) {
            
            sheets = []
            
            let test: [[String]]? = UserDefaults.standard.array(forKey: "sheetsInfo") as? [[String]]
            if (test != nil && test!.count > 0) {
                
                var sheetsInfo: [[String]] = UserDefaults.standard.array(forKey: "sheetsInfo") as! [[String]]
                var sheetsCoords: [[[String]]] = UserDefaults.standard.array(forKey: "sheetsCoords") as! [[[String]]]
                
                for i in 0...sheetsInfo.count-1 {
                    
                    let newSheet = DotSheet()
                    newSheet.setTitle(sheetsInfo[i][0])
                    newSheet.setField(sheetsInfo[i][1])
                    
                    for j in 0...sheetsCoords[i].count-1 {
                        
                        let newCoord = Coordinate()
                        newCoord.setLabel(sheetsCoords[i][j][0])
                        newCoord.setCts(sheetsCoords[i][j][1])
                        
                        var newX: [String] = []
                        for p in 2...5 {
                            newX.append(sheetsCoords[i][j][p])
                        }
                        newCoord.setX(newX)
                        
                        var newY: [String] = []
                        for p in 6...8 {
                            newY.append(sheetsCoords[i][j][p])
                        }
                        newCoord.setY(newY)
                        
                        newSheet.addCoord(newCoord)
                        
                        
                    }
                    
                    sheets.append(newSheet)
                    
                }
                
                justLaunched = false
                
            }
            
            
            
        }
 
        for sheet in sheets {
            print("sheet name: \(sheet.getTitle()!)")
        }
        
    }
    
    
    /*
     // MARK: - Navigation
     
     // In a storyboard-based application, you will often want to do a little preparation before navigation
     override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
     // Get the new view controller using segue.destination.
     // Pass the selected object to the new view controller.
     }
     */
    
    
    @IBAction func addButton(_ sender: Any) {
        performSegue(withIdentifier: "toNewDot", sender: self)
    }
    
    
    
    
    
}



extension EntriesController: UITableViewDelegate, UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return sheets.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "SheetCell")!
        
        let sheetName = sheets[indexPath.row].getTitle()!
        
        cell.textLabel?.text = sheetName
        cell.textLabel?.textColor = #colorLiteral(red: 1.0, green: 1.0, blue: 1.0, alpha: 1.0)
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        myIndex = indexPath.row
        
        performSegue(withIdentifier: "toDotView", sender: self)
    }
    
    func tableView(_ tableView: UITableView, leadingSwipeActionsConfigurationForRowAt indexPath: IndexPath) -> UISwipeActionsConfiguration? {
        
        
        
        let edit = UIContextualAction(style: .normal, title: "Edit") { (edit, view, nil) in
            print("Edit")
            
            editingCoords = true
            tempSheet = sheets[indexPath.row]
            
            self.performSegue(withIdentifier: "toNewDot", sender: self)
            
            
            
        }
        
        
        
        edit.backgroundColor = #colorLiteral(red: 0.3540963111, green: 0.2453525429, blue: 0.7051287241, alpha: 1)
        
        
        
        return UISwipeActionsConfiguration(actions: [edit])
    }
    
    func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        return true
    }
    
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        if (editingStyle == .delete) {
            sheets.remove(at: indexPath.row)
            
            var sheetsInfo: [[String]] = []
            var sheetsCoords: [[[String]]] = []

            for sheet in sheets {

                sheetsInfo.append(sheet.getInfo())
                sheetsCoords.append(sheet.getCoordsArray())


            }

            UserDefaults.standard.set(sheetsInfo, forKey: "sheetsInfo")
            UserDefaults.standard.set(sheetsCoords, forKey: "sheetsCoords")
            
            tableView.beginUpdates()
            tableView.deleteRows(at: [indexPath], with: .automatic)
            tableView.endUpdates()
        }
    }
    
}
