//
//  DrawView.swift
//  DotBuddy v3
//
//  Created by Julian Quevedo on 3/13/19.
//  Copyright © 2019 Julian Quevedo. All rights reserved.
//

import UIKit

enum Shape {
    case rectangle
}

class DrawView: UIView {
    
    var currentShape: Shape?
    
    // Only override draw() if you perform custom drawing.
    // An empty implementation adversely affects performance during animation.
    override func draw(_ rect: CGRect) {
        // Drawing code
        
        
        guard let currentContext = UIGraphicsGetCurrentContext() else {
            print("Could not get the context")
            return
        }
        
        drawRectangle(using: currentContext)
        
        
        
        
    }
    
    
    
    private func drawRectangle(using context: CGContext) {
        
        let xDistance: CGFloat = bounds.size.width/2 - 2
        let yDistance: CGFloat = bounds.size.height/2 - 2
        
        let r: CGFloat = 16
        
        let centerPoint = CGPoint(x: bounds.size.width/2, y: bounds.size.height/2)
        let lowerLeftCorner = CGPoint(x: centerPoint.x - xDistance, y: centerPoint.y + yDistance)
        let lowerLeftUpperLeft = CGPoint(x: centerPoint.x - xDistance, y: centerPoint.y + yDistance - r)
        let lowerLeftCenter = CGPoint(x: centerPoint.x - xDistance + r, y: centerPoint.y + yDistance - r)
        let lowerLeftLowerRight = CGPoint(x: centerPoint.x - xDistance + r, y: centerPoint.y + yDistance)
        
        let lowerRightCorner = CGPoint(x: centerPoint.x + xDistance, y: centerPoint.y + yDistance)
        let lowerRightUpperRight = CGPoint(x: centerPoint.x + xDistance, y: centerPoint.y + yDistance - r)
        let lowerRightCenter = CGPoint(x: centerPoint.x + xDistance - r, y: centerPoint.y + yDistance - r)
        let lowerRightLowerLeft = CGPoint(x: centerPoint.x + xDistance - r, y: centerPoint.y + yDistance)
        
        
        let upperRightCorner = CGPoint(x: centerPoint.x + xDistance, y: centerPoint.y - yDistance)
        let upperRightLowerRight = CGPoint(x: centerPoint.x + xDistance, y: centerPoint.y - yDistance + r)
        let upperRightCenter = CGPoint(x: centerPoint.x + xDistance - r, y: centerPoint.y - yDistance + r)
        let upperRightUpperLeft = CGPoint(x: centerPoint.x + xDistance - r, y: centerPoint.y - yDistance)
        
        
        let upperLeftCorner = CGPoint(x: centerPoint.x - xDistance, y: centerPoint.y - yDistance)
        let upperLeftLowerLeft = CGPoint(x: centerPoint.x - xDistance, y: centerPoint.y - yDistance + r)
        let upperLeftCenter = CGPoint(x: centerPoint.x - xDistance + r, y: centerPoint.y - yDistance + r)
        let upperLeftUpperRight = CGPoint(x: centerPoint.x - xDistance + r, y: centerPoint.y - yDistance)
        
        context.setLineCap(.round)
        context.setLineWidth(2)
        context.setStrokeColor(#colorLiteral(red: 0.3540963111, green: 0.2453525429, blue: 0.7051287241, alpha: 1))
        
        
        context.move(to: lowerLeftLowerRight)
        context.addLine(to: lowerLeftLowerRight)
        context.addLine(to: lowerRightLowerLeft)
        context.strokePath()
        
        //        context.move(to: lowerRightUpperRight)
        //        context.addLine(to: lowerRightUpperRight)
        //        context.addLine(to: upperRightLowerRight)
        //        context.strokePath()
        //
        //        context.move(to: upperRightUpperLeft)
        //        context.addLine(to: upperRightUpperLeft)
        //        context.addLine(to: upperLeftUpperRight)
        //        context.strokePath()
        
        context.move(to: upperLeftLowerLeft)
        context.addLine(to: upperLeftLowerLeft)
        context.addLine(to: lowerLeftUpperLeft)
        context.strokePath()
        
        context.addArc(center: lowerLeftCenter, radius: 16, startAngle: CGFloat(Double.pi/2), endAngle: CGFloat(Double.pi), clockwise: false)
        context.strokePath()
        
        //        context.addArc(center: upperRightCenter, radius: 16, startAngle: CGFloat(3*Double.pi/2), endAngle: CGFloat(0), clockwise: false)
        //        context.strokePath()
        
        
    }
    
    func drawShape(selectedShape: Shape) {
        currentShape = selectedShape
        setNeedsDisplay()
    }
    
    
}
