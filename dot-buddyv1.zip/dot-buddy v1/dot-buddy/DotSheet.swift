//
//  DotSheet.swift
//  DotBuddy v3
//
//  Created by Julian Quevedo on 3/13/19.
//  Copyright © 2019 Julian Quevedo. All rights reserved.
//

import Foundation

class DotSheet {
    
    private var title: String?
    private var coords: [Coordinate]
    private var fieldType: String?
    
    
    public init () {
        
        title = ""
        coords = []
        fieldType = ""
        
    }
    
    public func setTitle(_ newTitle: String?) {
        
        title = newTitle
        
    }
    
    
    public func addCoord(_ coord: Coordinate) {
        
        coords.append(coord)
        
    }
    
    public func setField(_ field: String?) {
        
        fieldType = field
        
    }
    
    public func getTitle() -> String? {
        
        return title
        
    }
    
    public func getCoords() -> [Coordinate] {
        
        return coords
        
    }
    
    public func getFieldType() -> String? {
        
        return fieldType
        
    }
    
    public func getInfo() -> [String] {
        
        return [self.title!,self.fieldType!]
        
    }
    
    public func getCoordsArray() -> [[String]] {
        
        var coordsArray: [[String]] = []
        
        for coord in self.coords {
            
            coordsArray.append(coord.toArray())
            
        }
        
        return coordsArray
        
    }
    
    
}



