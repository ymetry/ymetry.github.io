//
//  NewDotController.swift
//  DotBuddy v3
//
//  Created by Julian Quevedo on 3/13/19.
//  Copyright © 2019 Julian Quevedo. All rights reserved.
//

import UIKit



class NewDotController: UIViewController {
    
    @IBOutlet weak var sheetName: UITextField!
    
    @IBOutlet weak var num1: UITextField!
    @IBOutlet weak var info1: DotInputView!
    
    
    @IBOutlet weak var num2: UITextField!
    @IBOutlet weak var info2: DotInputView!
    
    
    @IBOutlet weak var num3: UITextField!
    @IBOutlet weak var info3: DotInputView!
    
    @IBOutlet weak var num4: UITextField!
    @IBOutlet weak var info4: DotInputView!
    
    @IBOutlet weak var num5: UITextField!
    @IBOutlet weak var info5: DotInputView!
    
    @IBOutlet weak var num6: UITextField!
    @IBOutlet weak var info6: DotInputView!
    
    @IBOutlet weak var num7: UITextField!
    @IBOutlet weak var info7: DotInputView!
    
    @IBOutlet weak var num8: UITextField!
    @IBOutlet weak var info8: DotInputView!
    
    @IBOutlet weak var num9: UITextField!
    @IBOutlet weak var info9: DotInputView!
    
    @IBOutlet weak var num10: UITextField!
    @IBOutlet weak var info10: DotInputView!
    
    @IBOutlet weak var num11: UITextField!
    @IBOutlet weak var info11: DotInputView!
    
    @IBOutlet weak var num12: UITextField!
    @IBOutlet weak var info12: DotInputView!
    
    @IBOutlet weak var num13: UITextField!
    @IBOutlet weak var info13: DotInputView!
    
    @IBOutlet weak var num14: UITextField!
    @IBOutlet weak var info14: DotInputView!
    
    @IBOutlet weak var num15: UITextField!
    @IBOutlet weak var info15: DotInputView!
    
    @IBOutlet weak var num16: UITextField!
    @IBOutlet weak var info16: DotInputView!
    
    @IBOutlet weak var num17: UITextField!
    @IBOutlet weak var info17: DotInputView!
    
    @IBOutlet weak var num18: UITextField!
    @IBOutlet weak var info18: DotInputView!
    
    @IBOutlet weak var num19: UITextField!
    @IBOutlet weak var info19: DotInputView!
    
    @IBOutlet weak var num20: UITextField!
    @IBOutlet weak var info20: DotInputView!
    
    @IBOutlet weak var num21: UITextField!
    @IBOutlet weak var info21: DotInputView!
    
    @IBOutlet weak var num22: UITextField!
    @IBOutlet weak var info22: DotInputView!
    
    @IBOutlet weak var num23: UITextField!
    @IBOutlet weak var info23: DotInputView!
    
    @IBOutlet weak var num24: UITextField!
    @IBOutlet weak var info24: DotInputView!
    
    @IBOutlet weak var num25: UITextField!
    @IBOutlet weak var info25: DotInputView!
    
    @IBOutlet weak var num26: UITextField!
    @IBOutlet weak var info26: DotInputView!
    
    @IBOutlet weak var num27: UITextField!
    @IBOutlet weak var info27: DotInputView!
    
    @IBOutlet weak var num28: UITextField!
    @IBOutlet weak var info28: DotInputView!
    
    @IBOutlet weak var num29: UITextField!
    @IBOutlet weak var info29: DotInputView!
    
    @IBOutlet weak var num30: UITextField!
    @IBOutlet weak var info30: DotInputView!
    
    @IBOutlet weak var num31: UITextField!
    @IBOutlet weak var info31: DotInputView!
    
    @IBOutlet weak var num32: UITextField!
    @IBOutlet weak var info32: DotInputView!
    
    @IBOutlet weak var num33: UITextField!
    @IBOutlet weak var info33: DotInputView!
    
    @IBOutlet weak var num34: UITextField!
    @IBOutlet weak var info34: DotInputView!
    
    @IBOutlet weak var num35: UITextField!
    @IBOutlet weak var info35: DotInputView!
    
    @IBOutlet weak var num36: UITextField!
    @IBOutlet weak var info36: DotInputView!
    
    @IBOutlet weak var num37: UITextField!
    @IBOutlet weak var info37: DotInputView!
    
    @IBOutlet weak var num38: UITextField!
    @IBOutlet weak var info38: DotInputView!
    
    @IBOutlet weak var num39: UITextField!
    @IBOutlet weak var info39: DotInputView!
    
    @IBOutlet weak var num40: UITextField!
    @IBOutlet weak var info40: DotInputView!
    
    @IBOutlet weak var fieldSelect: UISegmentedControl!
    
    var coordLabels: [UITextField] = []
    
    var infoViews: [DotInputView] = []
    
    var goodViews: [DotInputView] = []
    
    let newSheet: DotSheet = DotSheet()
    
    var baddies: [Int] = []
    var orderedBaddies: [Int] = []
    
    var xSides: [String] = []
    var xPlaces: [String] = []
    var yPlaces: [String] = []
    var xLines: [String] = []
    var yLines: [String] = []
    
    var field: String = ""
    var fields: [String] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
        
        infoViews = [
            
            info1,info2,info3,info4,info5,info6,info7,info8,info9,info10,info11,info12,info13,info14,info15,info16,info17,info18,info19,info20,info21,info22,info23,info24,info25,info26,info27,info28,info29,info30,info31,info32,info33,info34,info35,info36,info37,info38,info39,info40
            
        ]
        
        coordLabels = [
            
            num1,num2,num3,num4,num5,num6,num7,num8,num9,num10,num11,num12,num13,num14,num15,num16,num17,num18,num19,num20,num21,num22,num23,num24,num25,num26,num27,num28,num29,num30,num31,num32,num33,num34,num35,num36,num37,num38,num39,num40
            
        ]
        
        
        
        xSides = ["s1","s2"]
        xPlaces = ["on","inside","outside"]
        yPlaces = ["on","in front","behind"]
        xLines = ["50","45","40","35","30","25","20","15","10","5","0"]
        yLines = ["F SL","F H","B H","B SL"]
        
        fields = ["HS","NCAA"]
        
        
        
        if (editingCoords) {
            print("editing? \(editingCoords)")
            updateCoords(dotSheet: tempSheet)
            
            editingCoords = false
            tempSheet = DotSheet()
        }
        
        for info in infoViews {
            
            info.xSide = xSides[info.xSidePicker.selectedSegmentIndex]
            info.xPlace = xPlaces[info.xPlacePicker.selectedSegmentIndex]
            info.yPlace = yPlaces[info.yPlacePicker.selectedSegmentIndex]
            
            info.xLine = xLines[info.ydPicker.selectedRow(inComponent: 0)]
            info.yLine = yLines[info.hashPicker.selectedRow(inComponent: 0)]
            
        }
        
        field = fields[fieldSelect.selectedSegmentIndex]
        
        
    }
    
    
    
    
    func updateCoords(dotSheet: DotSheet) {
        
        sheetName.text = dotSheet.getTitle()
        if (dotSheet.getFieldType() == "HS") {
            fieldSelect.selectedSegmentIndex = 0
        }
        else if (dotSheet.getFieldType() == "NCAA") {
            fieldSelect.selectedSegmentIndex = 1
        }
        
        let coords = dotSheet.getCoords()
        
        for i in 0...coords.count-1 {
            
            coordLabels[i].text = coords[i].getLabel()
            
            infoViews[i].counts.text = coords[i].getCts()
            infoViews[i].xNum.text = coords[i].getX()[1]
            infoViews[i].yNum.text = coords[i].getY()[0]
            
            let thisXSide = coords[i].getX()[0]
            let thisXPlace = coords[i].getX()[2]
            let thisXLine = coords[i].getX()[3]
            
            let thisYPlace = coords[i].getY()[1]
            let thisYLine = coords[i].getY()[2]
            
            let ydLines = ["50","45","40","35","30","25","20","15","10","5","0"]
            let hashLines = ["F SL","F H","B H","B SL"]
            
            for y in 0...ydLines.count-1 {
                
                if (thisXLine == ydLines[y]) {
                    
                    infoViews[i].ydPicker.reloadAllComponents()
                    
                    infoViews[i].ydPicker.selectRow(y, inComponent: 0, animated: true)
                }
                
            }
            
            for h in 0...hashLines.count-1 {
                
                if (thisYLine == hashLines[h]) {
                    
                    infoViews[i].hashPicker.reloadAllComponents()
                    
                    infoViews[i].hashPicker.selectRow(h, inComponent: 0, animated: true)
                }
                
            }
            
            for xS in 0...xSides.count-1 {
                
                if (thisXSide == xSides[xS]) {
                    
                    infoViews[i].xSidePicker.selectedSegmentIndex = xS
                }
                
            }
            
            for xP in 0...xPlaces.count-1 {
                
                if (thisXPlace == xPlaces[xP]) {
                    infoViews[i].xPlacePicker.selectedSegmentIndex = xP
                }
                
            }
            
            for yP in 0...yPlaces.count-1 {
                
                if (thisYPlace == yPlaces[yP]) {
                    infoViews[i].yPlacePicker.selectedSegmentIndex = yP
                }
                
            }
            
        }
        
    }
    
    
    @IBAction func fieldSelected(_ sender: Any) {
        
        field = fields[fieldSelect.selectedSegmentIndex]
        
    }
    
    
    
    
    @IBAction func save(_ sender: Any) {
        
        baddies = []
        goodViews = []
        
        newSheet.setTitle(sheetName.text)
        
        for i in 0...infoViews.count-1 {
            
            let str: String! = coordLabels[i].text
            
            if (infoViews[i].xPlace == "on") {
                infoViews[i].xNum.text = ""
            }
            if (infoViews[i].yPlace == "on") {
                infoViews[i].yNum.text = ""
            }
            
            if (i == 0) {
                
                
                if (infoViews[i].xPlace == "on" && infoViews[i].yPlace == "on") {
                    if (str != "" && Int(str.prefix(1)) != nil) {
                        goodViews.append(infoViews[i])
                    }
                    
                }
                else if ((infoViews[i].xPlace != "on" && infoViews[i].xNum.text != "") && infoViews[i].yPlace == "on") {
                    if (str != "" && Int(str.prefix(1)) != nil) {
                        goodViews.append(infoViews[i])
                    }
                }
                else if ((infoViews[i].yPlace != "on" && infoViews[i].yNum.text != "") && infoViews[i].xPlace == "on") {
                    if (str != "" && Int(str.prefix(1)) != nil) {
                        goodViews.append(infoViews[i])
                    }
                }
                else if ((infoViews[i].xPlace != "on" && infoViews[i].xNum.text != "") && (infoViews[i].yPlace != "on" && infoViews[i].yNum.text != "")) {
                    if (str != "" && Int(str.prefix(1)) != nil) {
                        goodViews.append(infoViews[i])
                    }
                }
                
            }
            
            if (infoViews[i].counts.text != "" && i > 0) {
                if (infoViews[i].xPlace == "on" && infoViews[i].yPlace == "on") {
                    if (str != "" && Int(str.prefix(1)) != nil) {
                        goodViews.append(infoViews[i])
                    }
                    
                }
                else if ((infoViews[i].xPlace != "on" && infoViews[i].xNum.text != "") && infoViews[i].yPlace == "on") {
                    if (str != "" && Int(str.prefix(1)) != nil) {
                        goodViews.append(infoViews[i])
                    }
                }
                else if ((infoViews[i].yPlace != "on" && infoViews[i].yNum.text != "") && infoViews[i].xPlace == "on") {
                    if (str != "" && Int(str.prefix(1)) != nil) {
                        goodViews.append(infoViews[i])
                    }
                }
                else if ((infoViews[i].xPlace != "on" && infoViews[i].xNum.text != "") && (infoViews[i].yPlace != "on" && infoViews[i].yNum.text != "")) {
                    if (str != "" && Int(str.prefix(1)) != nil) {
                        goodViews.append(infoViews[i])
                    }
                }
                
            }
            
        }
        
        if (goodViews.count > 0) {
            
            
            var goodIdx = 0;
            for i in 0...infoViews.count-1 {
                
                
                if (goodIdx < goodViews.count && infoViews[i] != goodViews[goodIdx]) {
                    
                    baddies.append(i)
                    goodIdx -= 1
                    
                }
                
                goodIdx += 1
                
                
                
            }
            
            
            if (baddies.count > 0) {
                for i in 0...baddies.count-1 {
                    
                    var count = 0
                    
                    for j in 0...baddies.count-1 {
                        
                        if (baddies[i] == baddies[j]) {
                            count += 1
                        }
                        
                    }
                    
                    if (count > 1) {
                        baddies.remove(at: i)
                    }
                    
                }
            }
            
            
            if (baddies.count == 0) {
                
                for i in 0...goodViews.count-1 {
                    
                    let newCoord: Coordinate = Coordinate()
                    
                    newCoord.setCts(goodViews[i].counts.text)
                    newCoord.setX([goodViews[i].xSide,goodViews[i].xNum.text,goodViews[i].xPlace,goodViews[i].xLine])
                    newCoord.setY([goodViews[i].yNum.text,goodViews[i].yPlace,goodViews[i].yLine])
                    newCoord.setLabel(coordLabels[i].text)
                    
                    newSheet.addCoord(newCoord)
                }
                
                newSheet.setField(field)
                
                var count: Int = 0
                var idx: Int = 0;
                
                for sheet in sheets {
                    if (sheet.getTitle() == newSheet.getTitle()) {
                        sheets[idx] = newSheet
                        count += 1
                    }
                    idx += 1;
                }
                if (count == 0) {
                    sheets.append(newSheet)
                }
                
                
                
                var sheetsInfo: [[String]] = []
                var sheetsCoords: [[[String]]] = []
                
                for sheet in sheets {
                    
                    sheetsInfo.append(sheet.getInfo())
                    sheetsCoords.append(sheet.getCoordsArray())
                    
                    
                }
                
                UserDefaults.standard.set(sheetsInfo, forKey: "sheetsInfo")
                UserDefaults.standard.set(sheetsCoords, forKey: "sheetsCoords")
            
 
                performSegue(withIdentifier: "toEntries", sender: self)
                
            }
            else {
                
                baddies.sort()
                
                var badList = ""
                
                for i in 0...baddies.count-1 {
                    
                    if (badList.count > 0) {
                        badList += ", \(baddies[i]+1)"
                    }
                    else {
                        badList += "\(baddies[i]+1)"
                    }
                    
                }
                
                createAlert(title: "Invalid Input", message: "There's something wrong with set(s) " + badList)
                
                
                
                
            }
        }
        else {
            createAlert(title: "Invalid Input", message: "Please input at least one valid dot")
        }
        
        
        
        
        
        
        
    }
    
    
    
    func createAlert(title: String, message: String) {
        
        let alert = UIAlertController(title: title, message: message, preferredStyle: UIAlertController.Style.alert)
        
        alert.addAction(UIAlertAction(title: "Dismiss", style: UIAlertAction.Style.default, handler: { (action) in
            alert.dismiss(animated: true, completion: nil)
        }))
        
        self.present(alert, animated: true, completion: nil)
    }
    
    @IBAction func cancel(_ sender: Any) {
        performSegue(withIdentifier: "toEntries", sender: self)
    }
    
    @IBAction func l1(_ sender: Any) {
        checkChange(idx: 0)
    }
    @IBAction func l2(_ sender: Any) {
        checkChange(idx: 1)
    }
    @IBAction func l3(_ sender: Any) {
        checkChange(idx: 2)
    }
    @IBAction func l4(_ sender: Any) {
        checkChange(idx: 3)
    }
    @IBAction func l5(_ sender: Any) {
        checkChange(idx: 4)
    }
    @IBAction func l6(_ sender: Any) {
        checkChange(idx: 5)
    }
    @IBAction func l7(_ sender: Any) {
        checkChange(idx: 6)
    }
    @IBAction func l8(_ sender: Any) {
        checkChange(idx: 7)
    }
    @IBAction func l9(_ sender: Any) {
        checkChange(idx: 8)
    }
    @IBAction func l10(_ sender: Any) {
        checkChange(idx: 9)
    }
    @IBAction func l11(_ sender: Any) {
        checkChange(idx: 10)
    }
    @IBAction func l12(_ sender: Any) {
        checkChange(idx: 11)
    }
    @IBAction func l13(_ sender: Any) {
        checkChange(idx: 12)
    }
    @IBAction func l14(_ sender: Any) {
        checkChange(idx: 13)
    }
    @IBAction func l15(_ sender: Any) {
        checkChange(idx: 14)
    }
    @IBAction func l16(_ sender: Any) {
        checkChange(idx: 15)
    }
    @IBAction func l17(_ sender: Any) {
        checkChange(idx: 16)
    }
    @IBAction func l18(_ sender: Any) {
        checkChange(idx: 17)
    }
    @IBAction func l19(_ sender: Any) {
        checkChange(idx: 18)
    }
    @IBAction func l20(_ sender: Any) {
        checkChange(idx: 19)
    }
    @IBAction func l21(_ sender: Any) {
        checkChange(idx: 20)
    }
    @IBAction func l22(_ sender: Any) {
        checkChange(idx: 21)
    }
    @IBAction func l23(_ sender: Any) {
        checkChange(idx: 22)
    }
    @IBAction func l24(_ sender: Any) {
        checkChange(idx: 23)
    }
    @IBAction func l25(_ sender: Any) {
        checkChange(idx: 24)
    }
    @IBAction func l26(_ sender: Any) {
        checkChange(idx: 25)
    }
    @IBAction func l27(_ sender: Any) {
        checkChange(idx: 26)
    }
    @IBAction func l28(_ sender: Any) {
        checkChange(idx: 27)
    }
    @IBAction func l29(_ sender: Any) {
        checkChange(idx: 28)
    }
    @IBAction func l30(_ sender: Any) {
        checkChange(idx: 29)
    }
    @IBAction func l31(_ sender: Any) {
        checkChange(idx: 30)
    }
    @IBAction func l32(_ sender: Any) {
        checkChange(idx: 31)
    }
    @IBAction func l33(_ sender: Any) {
        checkChange(idx: 32)
    }
    @IBAction func l34(_ sender: Any) {
        checkChange(idx: 33)
    }
    @IBAction func l35(_ sender: Any) {
        checkChange(idx: 34)
    }
    @IBAction func l36(_ sender: Any) {
        checkChange(idx: 35)
    }
    @IBAction func l37(_ sender: Any) {
        checkChange(idx: 36)
    }
    @IBAction func l38(_ sender: Any) {
        checkChange(idx: 37)
    }
    @IBAction func l39(_ sender: Any) {
        checkChange(idx: 38)
    }
    @IBAction func l40(_ sender: Any) {
        checkChange(idx: 39)
    }
    
    private func checkChange(idx: Int) {
        
        let str: String! = coordLabels[idx].text
        var letterIndex = 0
        
        
        if (str != "" && Int(str.prefix(1)) != nil) {
            
            var isSubset = false
            
            for i in 1...str.count {
                if (Int(str.prefix(i)) == nil) {
                    isSubset = true
                    letterIndex = i-1
                }
            }
            
            
            
            if (isSubset) {
                
                let initVal: Int! = Int(str.prefix(letterIndex))
                var val = initVal+1
                
                for i in idx+1...coordLabels.count-1 {
                    
                    coordLabels[i].text = "\(val)"
                    val += 1
                    
                }
            }
            
            
            if (!isSubset) {
                
                if (idx < 39) {
                    
                    let nextStr: String! = coordLabels[idx+1].text
                    
                    let currentVal: Int! = Int(str)
                    let nextVal: Int! = Int(nextStr)
                    
                    var val = currentVal+1
                    
                    if (currentVal >= nextVal) {
                        
                        for i in idx+1...coordLabels.count-1 {
                            
                            coordLabels[i].text = "\(val)"
                            val += 1
                            
                        }
                        
                    }
                }
                
                
            }
            
            
            
            
            
            
            
            
        }
        
        
        
        
        
    }
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    /*
     // MARK: - Navigation
     
     // In a storyboard-based application, you will often want to do a little preparation before navigation
     override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
     // Get the new view controller using segue.destination.
     // Pass the selected object to the new view controller.
     }
     */
    
    
    
}
