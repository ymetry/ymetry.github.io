//
//  ViewController.swift
//  DotBuddy v3
//
//  Created by Julian Quevedo on 3/13/19.
//  Copyright © 2019 Julian Quevedo. All rights reserved.
//

import UIKit

var coordIdx = 0

class ViewController: UIViewController {
    
    
    @IBOutlet weak var drawView1: DrawView!
    
    @IBOutlet weak var drawView2: DrawView2!
    
    @IBOutlet weak var drawView3: DrawView3!
    
    @IBOutlet weak var drawView4: DrawView4!
    
    @IBOutlet weak var setLabel: UILabel!
    @IBOutlet weak var setCounts: UILabel!
    @IBOutlet weak var setXSide: UILabel!
    @IBOutlet weak var setX: UILabel!
    @IBOutlet weak var setY: UILabel!
    
    @IBOutlet weak var checkpoints: UITextView!
    @IBOutlet weak var stepsize: UILabel!
    @IBOutlet weak var toFive: UILabel!
    
    @IBOutlet weak var xChange: UILabel!
    @IBOutlet weak var yChange: UILabel!
    
    @IBOutlet weak var stepsPer: UILabel!
    @IBOutlet weak var stcount: UILabel!
    
    
    
    let currentSet = sheets[myIndex].getCoords()[coordIdx]
    var currentCoord: [Float] = []
    var prevCoord: [Float] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        
        let leftSwipe = UISwipeGestureRecognizer(target: self, action: #selector(swipeAction(swipe:)))
        leftSwipe.direction = UISwipeGestureRecognizer.Direction.left
        self.view.addGestureRecognizer(leftSwipe)
        
        let rightSwipe = UISwipeGestureRecognizer(target: self, action: #selector(swipeAction(swipe:)))
        rightSwipe.direction = UISwipeGestureRecognizer.Direction.right
        self.view.addGestureRecognizer(rightSwipe)
        
        let upSwipe = UISwipeGestureRecognizer(target: self, action: #selector(swipeAction(swipe:)))
        upSwipe.direction = UISwipeGestureRecognizer.Direction.up
        self.view.addGestureRecognizer(upSwipe)
        
        
        setLabel.text = currentSet.getLabel()
        
        if (currentSet.getCts()! == "") {
            setCounts.text = "0 counts"
        } else {
            setCounts.text = "\(currentSet.getCts()!) counts"
        }
        
        if (currentSet.getX()[2] == "on" && currentSet.getX()[3] == "50") {
            setXSide.text = ""
            setXSide.backgroundColor = #colorLiteral(red: 0.1215686277, green: 0.1294117719, blue: 0.1411764771, alpha: 1)
        } else {
            setXSide.text = currentSet.getX()[0]
            setXSide.backgroundColor = #colorLiteral(red: 0.8039215803, green: 0.8039215803, blue: 0.8039215803, alpha: 1)
        }
        
        
        if (currentSet.getX()[1]! == "") {
            setX.text = "\(currentSet.getX()[2]!) \(currentSet.getX()[3]!)"
        } else {
            setX.text = "\(currentSet.getX()[1]!) \(currentSet.getX()[2]!) \(currentSet.getX()[3]!)"
        }
        
        if (currentSet.getY()[0]! == "") {
            setY.text = "\(currentSet.getY()[1]!) \(currentSet.getY()[2]!)"
        } else {
            setY.text = "\(currentSet.getY()[0]!) \(currentSet.getY()[1]!) \(currentSet.getY()[2]!)"
        }
        
        checkpoints.text = ""
        stepsize.text = ""
        toFive.text = ""
        xChange.text = ""
        yChange.text = ""
        stepsPer.text = ""
        stcount.text = ""
        
        
        if (coordIdx > 0) {
            currentCoord = calculateCoords(currentIdx: coordIdx)
            prevCoord = calculateCoords(currentIdx: coordIdx-1)
            
            let deltaX = Double(currentCoord[0] - prevCoord[0])
            let deltaY = Double(currentCoord[1] - prevCoord[1])
            
            if (deltaX == 0 && deltaY == 0) {
                checkpoints.text = "\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nNo checkpoints for holds :^)"
            } else {
                
                let checks = calculateCheckpoints(firstCoord: prevCoord, secondCoord: currentCoord)
                
                let strChecks = convertCheckpoints(checks: checks)
                
                var output = ""
                
                for i in 0...strChecks.count-1 {
                    
                    output += "\n(\(i+1)) \(strChecks[i][0])"
                    output += "\n           \(strChecks[i][1])"
                    
                    
                }
                checkpoints.text = output
                
                
                
                let xRounded = round(deltaX * 100)/100.0
                let yRounded = round(deltaY * 100)/100.0
                
                xChange.text = "ΔX = \(xRounded)"
                yChange.text = "ΔY = \(yRounded)"
                
                let dist = (pow(deltaX,2) + pow(deltaY,2)).squareRoot()
                let delta = dist/Double(currentSet.getCts()!)!
                
                let stepVal = round(8/delta * 100) / 100.0
                
                stepsize.text = "\(stepVal)"
                toFive.text = "to-five"
                
                let roundedDelta = round(delta * 100) / 100.0
                stepsPer.text = "\(roundedDelta)"
                stcount.text = "st/count"
            }
            
            
            
            
            
        } else {
            
            checkpoints.text = "\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nNo checkpoints for the first set :^)"
            
        }
        
        
        
    }
    
    
    func calculateCoords(currentIdx: Int) -> [Float] {
        
        let set = sheets[myIndex].getCoords()[currentIdx]
        
        var xCoord: Float! = 0.0
        
        if (set.getX()[0]! == "s1") {
            if (set.getX()[3]! == "0") {
                xCoord = 0
            }
            if (set.getX()[3]! == "5") {
                xCoord = 8
            }
            if (set.getX()[3]! == "10") {
                xCoord = 16
            }
            if (set.getX()[3]! == "15") {
                xCoord = 24
            }
            if (set.getX()[3]! == "20") {
                xCoord = 32
            }
            if (set.getX()[3]! == "25") {
                xCoord = 40
            }
            if (set.getX()[3]! == "30") {
                xCoord = 48
            }
            if (set.getX()[3]! == "35") {
                xCoord = 56
            }
            if (set.getX()[3]! == "40") {
                xCoord = 64
            }
            if (set.getX()[3]! == "45") {
                xCoord = 72
            }
            if (set.getX()[3]! == "50") {
                xCoord = 80
            }
            
            if (set.getX()[2]! == "inside") {
                xCoord += Float(set.getX()[1]!)!
            }
            if (set.getX()[2]! == "outside") {
                xCoord -= Float(set.getX()[1]!)!
            }
        }
        if (set.getX()[0]! == "s2") {
            if (set.getX()[3]! == "0") {
                xCoord = 160
            }
            if (set.getX()[3]! == "5") {
                xCoord = 152
            }
            if (set.getX()[3]! == "10") {
                xCoord = 144
            }
            if (set.getX()[3]! == "15") {
                xCoord = 136
            }
            if (set.getX()[3]! == "20") {
                xCoord = 128
            }
            if (set.getX()[3]! == "25") {
                xCoord = 120
            }
            if (set.getX()[3]! == "30") {
                xCoord = 112
            }
            if (set.getX()[3]! == "35") {
                xCoord = 104
            }
            if (set.getX()[3]! == "40") {
                xCoord = 96
            }
            if (set.getX()[3]! == "45") {
                xCoord = 88
            }
            if (set.getX()[3]! == "50") {
                xCoord = 80
            }
            
            if (set.getX()[2]! == "inside") {
                xCoord -= Float(set.getX()[1]!)!
            }
            if (set.getX()[2]! == "outside") {
                xCoord += Float(set.getX()[1]!)!
            }
        }
        
        var yCoord: Float! = 0.0
        let thisField = sheets[myIndex].getFieldType()
        
        
        if (thisField == "HS") {
            
            if (set.getY()[2] == "F SL") {
                yCoord = 0
            }
            if (set.getY()[2] == "F H") {
                yCoord = 28
            }
            if (set.getY()[2] == "B H") {
                yCoord = 56
            }
            if (set.getY()[2] == "B SL") {
                yCoord = 84
            }
            
            if (set.getY()[1] == "in front") {
                yCoord -= Float(set.getY()[0]!)!
            }
            if (set.getY()[1] == "behind") {
                yCoord += Float(set.getY()[0]!)!
            }
            
        }
        
        if (thisField == "NCAA") {
            
            if (set.getY()[2] == "F SL") {
                yCoord = 0
            }
            if (set.getY()[2] == "F H") {
                yCoord = 32
            }
            if (set.getY()[2] == "B H") {
                yCoord = 48
            }
            if (set.getY()[2] == "B SL") {
                yCoord = 80
            }
            
            if (set.getY()[1] == "in front") {
                yCoord -= Float(set.getY()[0]!)!
            }
            if (set.getY()[1] == "behind") {
                yCoord += Float(set.getY()[0]!)!
            }
            
        }
        
        return [xCoord,yCoord]
        
    }
    
    
    func calculateCheckpoints(firstCoord: [Float], secondCoord: [Float]) -> [[Float]] {
        
        let deltaX = secondCoord[0]-firstCoord[0]
        let deltaY = secondCoord[1]-firstCoord[1]
        
        let num = Int(currentSet.getCts()!)!
        var checks: [[Float]] = []
        
        let incX = deltaX / Float(num)
        let incY = deltaY / Float(num)
        
        var tempCoord: [Float] = firstCoord
        
        for i in 1...num {
            tempCoord[0] += incX
            tempCoord[1] += incY
            
            checks.append(tempCoord)
        }
        
        return checks
        
    }
    
    func convertCheckpoints(checks: [[Float]]) -> [[String]] {
        
        var strChecks: [[String]] = []
        let ydLines = ["50","45","40","35","30","25","20","15","10","5","0"]
        
        for i in 0...checks.count-1 {
            
            var newXSide = ""
            var newXNum = ""
            var newXPlace = ""
            var newXLine = ""
            
            var newYNum = ""
            var newYPlace = ""
            var newYLine = ""
            
            let numX = checks[i][0]
            
            
            if (numX == 80) {
                newXSide = "  "
                newXNum = ""
                newXPlace = "on"
                newXLine = "50"
            }
            if (numX < 80) {
                newXSide = "s1"
                if (numX.truncatingRemainder(dividingBy: 8) == 0) {
                    newXPlace = "on"
                    newXNum = ""
                    var closest = Int(numX/8)
                    var idx = 10 - closest
                    newXLine = ydLines[idx]
                }
                else if (numX.truncatingRemainder(dividingBy: 8) < 4) {
                    newXPlace = "in"
                    newXNum = "\(numX.truncatingRemainder(dividingBy: 8))"
                    var closest = Int(numX/8)
                    var idx = 10 - closest
                    newXLine = ydLines[idx]
                }
                else if (numX.truncatingRemainder(dividingBy: 8) >= 4) {
                    newXPlace = "out"
                    newXNum = "\(8.0-numX.truncatingRemainder(dividingBy: 8))"
                    var closest = Int(numX/8) + 1
                    var idx = 10 - closest
                    newXLine = ydLines[idx]
                }
                
            }
            if (numX > 80) {
                newXSide = "s2"
                if (numX.truncatingRemainder(dividingBy: 8) == 0) {
                    newXPlace = "on"
                    newXNum = ""
                    var closest = Int(numX/8)
                    var idx = closest - 10
                    newXLine = ydLines[idx]
                }
                else if (numX.truncatingRemainder(dividingBy: 8) <= 4) {
                    newXPlace = "out"
                    newXNum = "\(numX.truncatingRemainder(dividingBy: 8))"
                    var closest = Int(numX/8)
                    var idx = closest - 10
                    newXLine = ydLines[idx]
                }
                else if (numX.truncatingRemainder(dividingBy: 8) > 4) {
                    newXPlace = "in"
                    newXNum = "\(8.0-numX.truncatingRemainder(dividingBy: 8))"
                    var closest = Int(numX/8) + 1
                    var idx = closest - 10
                    newXLine = ydLines[idx]
                }
                
                
            }
            
            
            let numY = checks[i][1]
            let thisField = sheets[myIndex].getFieldType()
            
            if (thisField == "HS") {
                if (numY < 14) {
                    newYLine = "F SL"
                    if (numY == 0) {
                        newYPlace = "on"
                        newYNum = ""
                    }
                    if (numY < 0) {
                        newYPlace = "front"
                        newYNum = "\(0 - numY)"
                    }
                    if (numY > 0) {
                        newYPlace = "behind"
                        newYNum = "\(numY)"
                        
                    }
                }
                else if (numY >= 14 && numY < 42) {
                    newYLine = "F H"
                    if (numY == 28) {
                        newYPlace = "on"
                        newYNum = ""
                    }
                    if (numY < 28) {
                        newYPlace = "front"
                        newYNum = "\(28 - numY)"
                    }
                    if (numY > 28) {
                        newYPlace = "behind"
                        newYNum = "\(numY - 28)"
                    }
                }
                else if (numY >= 42 && numY < 70) {
                    newYLine = "B H"
                    if (numY == 56) {
                        newYPlace = "on"
                        newYNum = ""
                    }
                    if (numY < 56) {
                        newYPlace = "front"
                        newYNum = "\(56 - numY)"
                    }
                    if (numY > 56) {
                        newYPlace = "behind"
                        newYNum = "\(numY - 56)"
                    }
                }
                else if (numY >= 70) {
                    newYLine = "B SL"
                    if (numY == 84) {
                        newYPlace = "on"
                        newYNum = ""
                    }
                    if (numY < 84) {
                        newYPlace = "front"
                        newYNum = "\(84 - numY)"
                    }
                    if (numY > 84) {
                        newYPlace = "behind"
                        newYNum = "\(numY - 84)"
                    }
                }
            }
            if (thisField == "NCAA") {
                if (numY < 16) {
                    newYLine = "F SL"
                    if (numY == 0) {
                        newYPlace = "on"
                        newYNum = ""
                    }
                    if (numY < 0) {
                        newYPlace = "front"
                        newYNum = "\(0 - numY)"
                    }
                    if (numY > 0) {
                        newYPlace = "behind"
                        newYNum = "\(numY)"
                        
                    }
                }
                else if (numY >= 16 && numY < 40) {
                    newYLine = "F H"
                    if (numY == 32) {
                        newYPlace = "on"
                        newYNum = ""
                    }
                    if (numY < 32) {
                        newYPlace = "front"
                        newYNum = "\(32 - numY)"
                    }
                    if (numY > 32) {
                        newYPlace = "behind"
                        newYNum = "\(numY - 32)"
                    }
                }
                else if (numY >= 40 && numY < 64) {
                    newYLine = "B H"
                    if (numY == 48) {
                        newYPlace = "on"
                        newYNum = ""
                    }
                    if (numY < 48) {
                        newYPlace = "front"
                        newYNum = "\(48 - numY)"
                    }
                    if (numY > 48) {
                        newYPlace = "behind"
                        newYNum = "\(numY - 48)"
                    }
                }
                else if (numY >= 64) {
                    newYLine = "B SL"
                    if (numY == 80) {
                        newYPlace = "on"
                        newYNum = ""
                    }
                    if (numY < 80) {
                        newYPlace = "front"
                        newYNum = "\(80 - numY)"
                    }
                    if (numY > 80) {
                        newYPlace = "behind"
                        newYNum = "\(numY - 80)"
                    }
                }
            }
            
            var xStr = ""
            var yStr = ""
            
            if (newXPlace == "on") {
                xStr = newXSide + " " + newXPlace + " " + newXLine
            } else {
                xStr = newXSide + " " + newXNum + " " + newXPlace + " " + newXLine
            }
            
            if (newYNum == "") {
                yStr = newYPlace + " " + newYLine
            } else {
                yStr = newYNum + " " + newYPlace + " " + newYLine
            }
            
            strChecks.append([xStr,yStr])
        }
        
        return strChecks
        
    }
    
    
    @objc func swipeAction(swipe:UISwipeGestureRecognizer) {
        
        if (swipe.direction == .left) {
            if (coordIdx < sheets[myIndex].getCoords().count-1) {
                coordIdx += 1
                performSegue(withIdentifier: "nextPage", sender: self)
            }
        }
        
        if (swipe.direction == .right) {
            if (coordIdx > 0) {
                coordIdx -= 1
                performSegue(withIdentifier: "prevPage", sender: self)
            }
        }
        
        if (swipe.direction == .up) {
            coordIdx = 0
            performSegue(withIdentifier: "backHome", sender: self)
        }
        
    }
    
    
    
}
