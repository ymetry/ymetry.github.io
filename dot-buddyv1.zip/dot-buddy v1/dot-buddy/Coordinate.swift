//
//  Coordinate.swift
//  DotBuddy v3
//
//  Created by Julian Quevedo on 3/13/19.
//  Copyright © 2019 Julian Quevedo. All rights reserved.
//

import Foundation

class Coordinate {
    
    private var label: String?
    private var cts: String?
    private var xCoord: [String?]
    private var yCoord: [String?]
    
    
    public init() {
        
        label = ""
        cts = ""
        xCoord = ["","","",""]
        yCoord = ["","",""]
        
    }
    
    public func setLabel(_ str: String?) {
        
        label = str
        
    }
    
    public func setCts(_ num: String?) {
        
        cts = num
        
    }
    
    
    public func setX(_ strs: [String?]) {
        
        xCoord = strs
        
    }
    
    public func setY(_ strs: [String?]) {
        
        yCoord = strs
        
    }
    
    public func getLabel() -> String! {
        
        return label
        
    }
    
    public func getCts() -> String? {
        
        return cts
        
    }
    
    public func getX() -> [String?] {
        
        return xCoord
        
    }
    
    public func getY() -> [String?] {
        
        return yCoord
        
    }
    
    public func toArray() -> [String] {
        
        var info: [String] = []
        info.append(self.label!)
        info.append(self.cts!)
        for i in 0...self.getX().count-1 {
            
            info.append(self.getX()[i]!)
            
        }
        for i in 0...self.getY().count-1 {
            
            info.append(self.getY()[i]!)
            
        }
        
        return info
        
    }
    
}
