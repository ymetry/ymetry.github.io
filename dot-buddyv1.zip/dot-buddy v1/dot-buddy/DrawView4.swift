//
//  DrawView4.swift
//  DotBuddy v3
//
//  Created by Julian Quevedo on 3/13/19.
//  Copyright © 2019 Julian Quevedo. All rights reserved.
//

import UIKit

enum Shape4 {
    case rectangle
}
class DrawView4: UIView {
    
    var currentShape: Shape4?
    
    // Only override draw() if you perform custom drawing.
    // An empty implementation adversely affects performance during animation.
    
    
    
    func drawVector() {
        if (coordIdx > 0) {
            let prevCoord = calculateCoords(currentIdx: coordIdx-1)
            let currentCoord = calculateCoords(currentIdx: coordIdx)
            
            let deltaX = Double(currentCoord[0] - prevCoord[0])
            let deltaY = Double(currentCoord[1] - prevCoord[1])
            
            
            let xLine = UIBezierPath()
            let yLine = UIBezierPath()
            let hyp = UIBezierPath()
            
            var scale = 0.0
            if (abs(deltaX) >= abs(deltaY)) {
                scale = abs(50/(deltaX - (0.25*deltaX)))
            } else {
                scale = abs(50/(deltaY - (0.25*deltaY)))
            }
            
            
            let lowerLeftCorner = CGPoint(x: 70, y: 90)
            let upperLeftCorner = CGPoint(x: 70, y: 20)
            let upperRightCorner = CGPoint(x: 170, y: 20)
            let lowerRightCorner = CGPoint(x: 170, y: 90)
            
            if (deltaX >= 0 && deltaY >= 0) {
                xLine.move(to: lowerLeftCorner)
                hyp.move(to: lowerLeftCorner)
                
                let corner = CGPoint(x: 70 + deltaX*scale, y: 90)
                xLine.addLine(to: corner)
                yLine.move(to: corner)
                
                let peak = CGPoint(x: 70 + deltaX*scale, y: 90 - deltaY*scale)
                yLine.addLine(to: peak)
                hyp.addLine(to: peak)
                
            }
            else if (deltaX < 0 && deltaY >= 0) {
                xLine.move(to: lowerRightCorner)
                hyp.move(to: lowerRightCorner)
                
                let corner = CGPoint(x: 170 + deltaX*scale, y: 90)
                xLine.addLine(to: corner)
                yLine.move(to: corner)
                
                let peak = CGPoint(x: 170 + deltaX*scale, y: 90 - deltaY*scale)
                yLine.addLine(to: peak)
                hyp.addLine(to: peak)
            }
            else if (deltaX >= 0 && deltaY < 0) {
                xLine.move(to: upperLeftCorner)
                hyp.move(to: upperLeftCorner)
                
                let corner = CGPoint(x: 70 + deltaX*scale, y: 20)
                xLine.addLine(to: corner)
                yLine.move(to: corner)
                
                let peak = CGPoint(x: 70 + deltaX*scale, y: 20 - deltaY*scale)
                yLine.addLine(to: peak)
                hyp.addLine(to: peak)
            }
            else if (deltaX < 0 && deltaY < 0) {
                xLine.move(to: upperRightCorner)
                hyp.move(to: upperRightCorner)
                
                let corner = CGPoint(x: 170 + deltaX*scale, y: 20)
                xLine.addLine(to: corner)
                yLine.move(to: corner)
                
                let peak = CGPoint(x: 170 + deltaX*scale, y: 20 - deltaY*scale)
                yLine.addLine(to: peak)
                hyp.addLine(to: peak)
            }
            
            xLine.lineWidth = 8
            yLine.lineWidth = 8
            hyp.lineWidth = 8
            
            xLine.lineCapStyle = .round
            yLine.lineCapStyle = .round
            hyp.lineCapStyle = .round
            
            #colorLiteral(red: 0.3333333433, green: 0.3333333433, blue: 0.3333333433, alpha: 1).setStroke()
            xLine.stroke()
            yLine.stroke()
            #colorLiteral(red: 0.3540963111, green: 0.2453525429, blue: 0.7051287241, alpha: 1).setStroke()
            hyp.stroke()
        }
        
        
        
    }
    
    override func draw(_ rect: CGRect) {
        // Drawing code
        
        guard let currentContext = UIGraphicsGetCurrentContext() else {
            print("Could not get the context")
            return
        }
        
        drawRectangle(using: currentContext)
        drawVector()
    }
    
    
    
    
    private func drawRectangle(using context: CGContext) {
        
        let xDistance: CGFloat = bounds.size.width/2 - 2
        let yDistance: CGFloat = bounds.size.height/2 - 2
        
        let r: CGFloat = 16
        
        let centerPoint = CGPoint(x: bounds.size.width/2, y: bounds.size.height/2)
        let lowerLeftCorner = CGPoint(x: centerPoint.x - xDistance, y: centerPoint.y + yDistance)
        let lowerLeftUpperLeft = CGPoint(x: centerPoint.x - xDistance, y: centerPoint.y + yDistance - r)
        let lowerLeftCenter = CGPoint(x: centerPoint.x - xDistance + r, y: centerPoint.y + yDistance - r)
        let lowerLeftLowerRight = CGPoint(x: centerPoint.x - xDistance + r, y: centerPoint.y + yDistance)
        
        let lowerRightCorner = CGPoint(x: centerPoint.x + xDistance, y: centerPoint.y + yDistance)
        let lowerRightUpperRight = CGPoint(x: centerPoint.x + xDistance, y: centerPoint.y + yDistance - r)
        let lowerRightCenter = CGPoint(x: centerPoint.x + xDistance - r, y: centerPoint.y + yDistance - r)
        let lowerRightLowerLeft = CGPoint(x: centerPoint.x + xDistance - r, y: centerPoint.y + yDistance)
        
        
        let upperRightCorner = CGPoint(x: centerPoint.x + xDistance, y: centerPoint.y - yDistance)
        let upperRightLowerRight = CGPoint(x: centerPoint.x + xDistance, y: centerPoint.y - yDistance + r)
        let upperRightCenter = CGPoint(x: centerPoint.x + xDistance - r, y: centerPoint.y - yDistance + r)
        let upperRightUpperLeft = CGPoint(x: centerPoint.x + xDistance - r, y: centerPoint.y - yDistance)
        
        
        let upperLeftCorner = CGPoint(x: centerPoint.x - xDistance, y: centerPoint.y - yDistance)
        let upperLeftLowerLeft = CGPoint(x: centerPoint.x - xDistance, y: centerPoint.y - yDistance + r)
        let upperLeftCenter = CGPoint(x: centerPoint.x - xDistance + r, y: centerPoint.y - yDistance + r)
        let upperLeftUpperRight = CGPoint(x: centerPoint.x - xDistance + r, y: centerPoint.y - yDistance)
        
        context.setLineCap(.round)
        context.setLineWidth(2)
        context.setStrokeColor(#colorLiteral(red: 0.3540963111, green: 0.2453525429, blue: 0.7051287241, alpha: 1))
        
        
        //        context.move(to: lowerLeftLowerRight)
        //        context.addLine(to: lowerLeftLowerRight)
        //        context.addLine(to: lowerRightLowerLeft)
        //        context.strokePath()
        
        context.move(to: lowerRightUpperRight)
        context.addLine(to: lowerRightUpperRight)
        context.addLine(to: upperRightLowerRight)
        context.strokePath()
        
        context.move(to: upperRightUpperLeft)
        context.addLine(to: upperRightUpperLeft)
        context.addLine(to: upperLeftUpperRight)
        context.strokePath()
        
        //        context.move(to: upperLeftLowerLeft)
        //        context.addLine(to: upperLeftLowerLeft)
        //        context.addLine(to: lowerLeftUpperLeft)
        //        context.strokePath()
        
        //        context.addArc(center: lowerLeftCenter, radius: 16, startAngle: CGFloat(Double.pi/2), endAngle: CGFloat(Double.pi), clockwise: false)
        //        context.strokePath()
        
        context.addArc(center: upperRightCenter, radius: 16, startAngle: CGFloat(3*Double.pi/2), endAngle: CGFloat(0), clockwise: false)
        context.strokePath()
    }
    
    func drawShape(selectedShape: Shape4) {
        currentShape = selectedShape
        setNeedsDisplay()
    }
    
    
    func calculateCoords(currentIdx: Int) -> [Float] {
        
        let set = sheets[myIndex].getCoords()[currentIdx]
        
        var xCoord: Float! = 0.0
        
        if (set.getX()[0]! == "s1") {
            if (set.getX()[3]! == "0") {
                xCoord = 0
            }
            if (set.getX()[3]! == "5") {
                xCoord = 8
            }
            if (set.getX()[3]! == "10") {
                xCoord = 16
            }
            if (set.getX()[3]! == "15") {
                xCoord = 24
            }
            if (set.getX()[3]! == "20") {
                xCoord = 32
            }
            if (set.getX()[3]! == "25") {
                xCoord = 40
            }
            if (set.getX()[3]! == "30") {
                xCoord = 48
            }
            if (set.getX()[3]! == "35") {
                xCoord = 56
            }
            if (set.getX()[3]! == "40") {
                xCoord = 64
            }
            if (set.getX()[3]! == "45") {
                xCoord = 72
            }
            if (set.getX()[3]! == "50") {
                xCoord = 80
            }
            
            if (set.getX()[2]! == "inside") {
                xCoord += Float(set.getX()[1]!)!
            }
            if (set.getX()[2]! == "outside") {
                xCoord -= Float(set.getX()[1]!)!
            }
        }
        if (set.getX()[0]! == "s2") {
            if (set.getX()[3]! == "0") {
                xCoord = 160
            }
            if (set.getX()[3]! == "5") {
                xCoord = 152
            }
            if (set.getX()[3]! == "10") {
                xCoord = 144
            }
            if (set.getX()[3]! == "15") {
                xCoord = 136
            }
            if (set.getX()[3]! == "20") {
                xCoord = 128
            }
            if (set.getX()[3]! == "25") {
                xCoord = 120
            }
            if (set.getX()[3]! == "30") {
                xCoord = 112
            }
            if (set.getX()[3]! == "35") {
                xCoord = 104
            }
            if (set.getX()[3]! == "40") {
                xCoord = 96
            }
            if (set.getX()[3]! == "45") {
                xCoord = 88
            }
            if (set.getX()[3]! == "50") {
                xCoord = 80
            }
            
            if (set.getX()[2]! == "inside") {
                xCoord -= Float(set.getX()[1]!)!
            }
            if (set.getX()[2]! == "outside") {
                xCoord += Float(set.getX()[1]!)!
            }
        }
        
        var yCoord: Float! = 0.0
        let thisField = sheets[myIndex].getFieldType()
        
        
        if (thisField == "HS") {
            
            if (set.getY()[2] == "F SL") {
                yCoord = 0
            }
            if (set.getY()[2] == "F H") {
                yCoord = 28
            }
            if (set.getY()[2] == "B H") {
                yCoord = 56
            }
            if (set.getY()[2] == "B SL") {
                yCoord = 84
            }
            
            if (set.getY()[1] == "in front") {
                yCoord -= Float(set.getY()[0]!)!
            }
            if (set.getY()[1] == "behind") {
                yCoord += Float(set.getY()[0]!)!
            }
            
        }
        
        if (thisField == "NCAA") {
            
            if (set.getY()[2] == "F SL") {
                yCoord = 0
            }
            if (set.getY()[2] == "F H") {
                yCoord = 32
            }
            if (set.getY()[2] == "B H") {
                yCoord = 48
            }
            if (set.getY()[2] == "B SL") {
                yCoord = 80
            }
            
            if (set.getY()[1] == "in front") {
                yCoord -= Float(set.getY()[0]!)!
            }
            if (set.getY()[1] == "behind") {
                yCoord += Float(set.getY()[0]!)!
            }
            
        }
        
        return [xCoord,yCoord]
        
    }
}
