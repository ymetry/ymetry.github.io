//
//  DotInputView.swift
//  DotBuddy
//
//  Created by Julian Quevedo on 2/4/19.
//  Copyright © 2019 Julian Quevedo. All rights reserved.
//

import UIKit

class DotInputView: UIView, UIPickerViewDelegate, UIPickerViewDataSource {
    
    
    @IBOutlet var view: UIView!
    
    @IBOutlet weak var ydPicker: UIPickerView!
    
    @IBOutlet weak var hashPicker: UIPickerView!
    
    @IBOutlet weak var counts: UITextField!
    
    @IBOutlet weak var xNum: UITextField!
    
    @IBOutlet weak var yNum: UITextField!

    @IBOutlet weak var xSidePicker: UISegmentedControl!
    
    @IBOutlet weak var xPlacePicker: UISegmentedControl!
    
    @IBOutlet weak var yPlacePicker: UISegmentedControl!
    
    
    
    var xSide = "s1"
    
    
    
    @IBAction func sidePicker(_ sender: UISegmentedControl) {
        if (sender.selectedSegmentIndex == 0) {
            xSide = "s1"
        }
        if (sender.selectedSegmentIndex == 1) {
            xSide = "s2"
        }
        
    }
    
    var xPlace = "on"
    
    @IBAction func xPlacePicker(_ sender: UISegmentedControl) {
        if (sender.selectedSegmentIndex == 0) {
            xPlace = "on"
        }
        if (sender.selectedSegmentIndex == 1) {
            xPlace = "inside"
        }
        if (sender.selectedSegmentIndex == 2) {
            xPlace = "outside"
        }
    }
    
    var yPlace = "on"
    
    @IBAction func yPlacePicker(_ sender: UISegmentedControl) {
        if (sender.selectedSegmentIndex == 0) {
            yPlace = "on"
        }
        if (sender.selectedSegmentIndex == 1) {
            yPlace = "in front"
        }
        if (sender.selectedSegmentIndex == 2) {
            yPlace = "behind"
        }
    }
    
    
    
    
    
    var xLine = "50"
    var yLine = "F SL"
    
    let ydLines = ["50","45","40","35","30","25","20","15","10","5","0"]
    let hashLines = ["F SL","F H","B H","B SL"]
    
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        if (pickerView == ydPicker) {
            return ydLines.count
        }
        else if (pickerView == hashPicker) {
            return hashLines.count
        }
        return 0
    }
    
    func pickerView(_ pickerView: UIPickerView, attributedTitleForRow row: Int, forComponent component: Int) -> NSAttributedString? {
        if (pickerView == ydPicker) {
            return NSAttributedString(string: ydLines[row], attributes: [NSAttributedString.Key.foregroundColor : UIColor.white])
        }
        else if (pickerView == hashPicker) {
            return NSAttributedString(string: hashLines[row], attributes: [NSAttributedString.Key.foregroundColor : UIColor.white])
        }
        return NSAttributedString(string: "", attributes: [NSAttributedString.Key.foregroundColor : UIColor.white])
    }
    
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        if (pickerView == ydPicker) {
            xLine = ydLines[row]
        }
        else if (pickerView == hashPicker) {
            yLine = hashLines[row]
        }
    }
    

    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        
        Bundle.main.loadNibNamed("DotInputView", owner: self, options: nil)
        self.addSubview(self.view)
        
    }
    
    

}
